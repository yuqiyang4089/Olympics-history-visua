var width = 1010;
//var height = 5800;
var height = 300;
var margin = 40;
var fisheye = d3.fisheye.circular()
    .radius(200)
    .distortion(2);
var vxScale = d3.scaleLinear().range([0, width]);
var vyScale = d3.scaleLinear().range([height-margin, 0]);
var c2 = d3.scaleOrdinal().range(["#4F94CD", "#FF6A6A"]).domain(["M", "F"]);
var c3 = d3.scaleOrdinal().range(["#FFFF00", "#4F94CD", "#FF6A6A", "#CCCCCC"]).domain(["Gold", "Silver", "Bronze", "NA"]);
var startyear = 1896;

var drawCareer = function(name, sport){
  vxScale = d3.scaleLinear().range([0, width]);
  vyScale = d3.scaleLinear().range([height-margin, 0]);
  
  if (name=="") {
    name = "CHN";
  };
  if (sport=="") {
    sport = "Swimming";
  }
  // load data with queue
  var url1 = "./data/newcareertime.csv";
  var url2 = "./data/new_df4.csv"; //the dataset only draw a link when # of medals is lager than 10

  var q = d3_queue.queue(1)
    .defer(d3.csv, url1)
    .defer(d3.csv, url2)
    .awaitAll(mydraw);
  
  function mydraw(error, data) {
    if (error) throw error;
    // Add a new svg
    //d3.select("#video").remove();
    var svg = d3.select("body").append("svg")
        .attr("id", "video")
        .attr("width", "100%")
        .attr("height", height)
        ;
    // Add a background rect for mousemove.
    svg.append("rect")
        .attr("class", "fishbackground")
        .attr("width", width)
        .attr("height", height-margin+20)
        .attr("x", "230px")
        .attr("y", "0px")
        .attr("fill", "#383838")
        ;

    d3.select("#vcontrol").remove();
    var vcontrol = d3.select("body").append("div").attr("id", "vcontrol").append("svg").attr("height", "45px");

    var title  = vcontrol.append("g").attr("id", "videotitle");
    title.append("text")
      .attr("y", "20px")
      .style("font-weight", "bold")
      .text("Athlete's Career");
    // title.append("text")
    //   .attr("y", "40px")
    //   .text("Country: " + name);
    // title.append("text")
    //   .attr("y", "60px")
    //   .text("Sport: " + sport);

    // Format the data
    data[0].forEach(function(d) {
      d.Year = +d.Year;
    });
    // Filter the data
    data[0] = data[0].filter(function(d){
      return d.NOC===name;
    });
    var mytime = d3.extent(data[0], function(d) { return d.Year; });

    var x0 = d3.extent(data[0], function(d) { return d.Year; })
    startyear = x0[0];
    vxScale.domain(x0);

    // data[0] = data[0].filter(function(d){
    //   return d.Year===year;
    // });
    data[0] = data[0].filter(function(d){
      return d.Sport===sport;
    });
    data[1] = data[1].filter(function(d){
      return d.NOC===name;
    });
    data[1] = data[1].filter(function(d){
      return d.Sport===sport;
    });
    

    data[1].forEach(function(d) {
      d.years = [];
      for (var i = 0; i<data[0].length; i++){
        if (d.ID==data[0][i].ID&&d.Sport==data[0][i].Sport) {
          d.years.push(data[0][i].Year)
        };
      };
    })
    // data[1] = data[1].filter(function(d){
    //   return d.years.length>=2 ;
    // })


    // Group the data
    // var sumsport = ['Basketball', 'Judo', 'Football', 'Tug-Of-War', 'Athletics', 'Swimming', 'Badminton', 'Sailing', 
    //                 'Gymnastics', 'Art Competitions', 'Handball', 'Weightlifting', 'Wrestling', 'Water Polo', 'Hockey', 
    //                 'Rowing', 'Fencing', 'Equestrianism', 'Shooting', 'Boxing', 'Taekwondo', 'Cycling', 'Diving', 
    //                 'Canoeing', 'Tennis', 'Modern Pentathlon', 'Golf', 'Softball', 'Archery', 'Volleyball', 
    //                 'Synchronized Swimming', 'Table Tennis', 'Baseball', 'Rhythmic Gymnastics', 'Rugby Sevens', 
    //                 'Trampolining', 'Beach Volleyball', 'Triathlon', 'Rugby', 'Lacrosse', 'Polo', 'Cricket', 'Ice Hockey', 
    //                 'Racquets', 'Motorboating', 'Croquet', 'Figure Skating', 'Jeu De Paume', 'Roque', 'Basque Pelota', 
    //                 'Alpinism', 'Aeronautics'];
    // var winsport = ['Speed Skating', 'Cross Country Skiing', 'Ice Hockey', 'Biathlon', 'Alpine Skiing', 'Luge', 
    //                 'Bobsleigh', 'Figure Skating', 'Nordic Combined', 'Freestyle Skiing', 'Ski Jumping', 'Curling', 
    //                 'Snowboarding', 'Short Track Speed Skating', 'Skeleton', 'Military Ski Patrol', 'Alpinism'];
    // // these sports are filtered by python
    // var summer = [[],[]];
    // for (var i = 0; i<sumsport.length; i++){
    //   summer[0][i] = data[0].filter(function(d){
    //     return d.Sport===sumsport[i];
    //   })
    //   summer[1][i] = data[1].filter(function(d){
    //     return d.Sport===sumsport[i];
    //   })
    // };
    // var winter = [[],[]];
    // for (var i = 0; i<winsport.length; i++){
    //   winter[0][i] = data[0].filter(function(d){
    //     return d.Sport===winsport[i];
    //   })
    //   winter[1][i] = data[1].filter(function(d){
    //     return d.Sport===sumsport[i];
    //   })
    // };

    //for (var i = 0; i<summer[0].length; i++) {
      var temp = 1;
      if (data[0].length!=0) {
        data[0][0].newid = 0;
        for (var j = 1; j<data[0].length; j++) {
          if (data[0][j].ID==data[0][j-1].ID) {
            data[0][j].newid = data[0][j-1].newid;
          } else {
            data[0][j].newid = temp;
            temp = temp + 1;
          }       
        }
      }

      if (data[1].length!=0) {
        for (var j = 0; j<data[1].length; j++) {          
          data[1][j].newid = j;                
        }
      }

      var y0 = [0,data[1].length+30];
      // y.domain(y0);
      vyScale.domain(y0);
    
    //};
    // console.log(data[0]);
    // console.log(data[1]);
    // draw points function
    var draw = function(group1, group2){
      var me = svg.append("g").attr("class", "liandci")
                  .attr("transform", "translate(230" + ", 20" + ")")
                  ;
      me
        .append("line")
        .attr("id", "timeline")
        .attr("x1", "0")
        .attr("x2", "0")
        .attr("y1", "0")
        .attr("y2", "260")
        .attr("stroke", "#DCDCDC")
        .attr("stroke-width", "1px")
        .style("opacity", 0.6)
        ;
      me.selectAll(".videocircle")
        .data(group1)
        .enter()
        .append("circle")
        // .attr("id", function(d) {
        //   return d.Sport + d.ID + d.Year;
        // })
        .attr("newid", function(d) {
          return d.newid;
        })
        .attr("class", function(d) {
          return "videocircle" + " videoci-" + d.ID +" y" + d.Year;
        })
        .attr("r", 2)
        .attr("cx", function(d) { 
          return vxScale(d.Year);
        })
        .attr("cy", function(d) {
          return vyScale(d.newid);
        })
        .attr("fill", function(d){
          return c2(d.Sex);
        })
        .style("opacity", 0)
        .on("mouseover", function(d){
          hlInPara1(d);
          showDetail1(d);
        })
        .on('mouseout', function(){
          cancelhl();
        });
      me.selectAll(".li")
        .data(group2)
        .enter()
        .append("line")
        .attr("class", "li")
        .attr("id", function(d){
          return "videoli-" + d.ID;
        })
        .attr("newid", function(d){
          var theid = d3.select(".videoci-" + d.ID).attr("newid");
          d.newid = theid;
          return d.newid;
        })
        .attr("x1", function(d){
          return vxScale(d.years[0]);
        })
        .attr("y1", function(d, i) {
          var theid = d3.select(".videoci-" + d.ID).attr("newid");
          return vyScale(theid);
        })
        // .attr("x2", function(d){
        //   return x(d.years[d.years.length-1]);
        // })
        .attr("x2", function(d){
          return vxScale(d.years[0]);
        })
        .attr("y2", function(d, i) {
          var theid = d3.select(".videoci-" + d.ID).attr("newid");
          return vyScale(theid);
        })
        .attr("stroke", function(d){
          return c2(d.Sex);
        })
        .attr("stroke-width", "2px")
        .on("mouseover", function(d){
          hlInPara2(d);
          showDetail2(d);
        })
        .on('mouseout', function(){
          d3.select("#p2").remove();
          d3.select("#videotooltip").classed("hidden", true);
          d3.select(".foreground").selectAll("path").attr("stroke", function(p){
        if (p.Medal==0){
          return "yellow";
        }
        else if (p.Medal==1){
          return "red";
        }
        else if (p.Medal==2){
          return "blue"
        }
        else if(p.Medal ==3) {
          return "gray"
        }else{
          return "white" 
        }})
       .attr("stroke-width","1px")
      .attr("opacity",function(p){
        if (p.Medal ==3){
          return 0.1
        }
      });
d3.select(".foreground_").selectAll("path").attr("stroke", function(p){
        if (p.Medal==0){
          return "yellow";
        }
        else if (p.Medal==1){
          return "red";
        }
        else if (p.Medal==2){
          return "blue"
        }
        else if(p.Medal ==3) {
          return "gray"
        }else{
          return "white" 
        }})
       .attr("stroke-width","1px")
      .attr("opacity",function(p){
        if (p.Medal ==3){
          return 0.1
        }
      });
      
        });
    };

    
    draw(data[0], data[1]);
    var notSort = true;

    // Add the X Axis
    var newtemp = (mytime[1] - mytime[0])/4;
    var xAxis = d3.axisBottom(vxScale).tickFormat(d3.format(".4r")).ticks(newtemp),
    yAxis = d3.axisLeft(vyScale);
    svg.append("g")
      .attr("class", "axis axis--x")
      .attr("transform", "translate(230," + (height-20) + ")")
      .call(xAxis);

    // Add the Y Axis
    svg.append("text")
        .attr("x","200px")
        .attr("y","10px")
        //.attr("transform",'rotate(-90)')
        .attr("fill","white")
        .attr("font-size","13px")
        .text("Athlete's id");

    svg.append("g")
      .attr('class', 'axis axis--y')
      .attr("transform", "translate(230" + ", 20" + ")")
      .call(yAxis)
      ;

    var upyear = startyear;
  
    var dataUpdatingInterval = setInterval(function() { 
      dotheupdate(upyear);
      upyear = upyear + 2;
      if (upyear>2016) {
        clearInterval(dataUpdatingInterval);
        d3.select("#timeline").transition("tldisappear").duration(600).style("opacity", 0);
        d3.selectAll(".videocircle").transition("finalcircle").delay(1000).duration(1000).style("opacity", 1);
        d3.selectAll(".li").transition("finalline").delay(1200).duration(1000).style("opacity", function(){

        });
        vxScale = d3.fisheye.scale(d3.scaleLinear).domain(x0).range([0, width]);
        vyScale = d3.fisheye.scale(d3.scaleLinear).domain(y0).range([height-margin, 0]);
        //radiusScale = d3.scaleSqrt().domain([0, 5e8]).range([0, 40]);
        xAxis = d3.axisBottom(vxScale).tickFormat(d3.format(".4r")).ticks(newtemp),
        yAxis = d3.axisLeft(vyScale);
        d3.select(".fishbackground").on("mousemove", function() {
          var mouse = d3.mouse(this);
          vxScale.distortion(2).focus(mouse[0]);
          vyScale.distortion(2).focus(mouse[1]);
          svg.select(".axis--x").call(xAxis);
          svg.select(".axis--y").call(yAxis);
          if (notSort) {
            fish1();
          } else {
            fish2();
          }    
        });
      }
    }, 400);

    // Positions the dots based on data.
    function position(dot) {
      dot.attr("cx", function(d) { return vxScale(d.Year); })
          .attr("cy", function(d) { return vyScale(d.newid); })
          //.attr("r", function(d) { return radiusScale(radius(d)); })
          ;
    }

    function fish1(){
      d3.selectAll(".videocircle").call(position);
      d3.select(".liandci").selectAll(".li")
        .attr("x1", function(d){
          return vxScale(d.years[0]);
        })
        .attr("y1", function(d, i) {
          var theid = d3.select(".videoci-" + d.ID).attr("newid");
          return vyScale(theid);
        })
        .attr("x2", function(d){
          return vxScale(d.years[(d.years.length-1)]);
        })
        .attr("y2", function(d, i) {
          var theid = d3.select(".videoci-" + d.ID).attr("newid");
          return vyScale(theid);
        });
    }

    function fish2(){
      d3.select(".liandci").selectAll(".li")
        .attr("x1", function(d){
          return vxScale(d.years[0]);
        })
        .attr("y1", function(d, i) {
          //var theid = d3.select(".videoci-" + d.ID).attr("newid");
          return vyScale(i);
        })
        .attr("x2", function(d){
          return vxScale(d.years[(d.years.length-1)]);
        })
        .attr("y2", function(d, i) {
          //var theid = d3.select(".videoci-" + d.ID).attr("newid");
          return vyScale(i);
        });
      d3.selectAll(".videocircle")
        .attr("cx", function(d) { return vxScale(d.Year); })
        .attr("cy", function(d) {
          var newy = d3.select("#videoli-"+d.ID).attr("newindex");
          return vyScale(newy);
        })
    }

    //////////////////////////////////////// reencoding ////////////////////////////////////////
    vcontrol
      .append("text")
      .attr("x", "0px")
      .attr("y", "43px")
      .text("Colored by: ");
    var encode = d3.select("#vcontrol").append("p");
    encode.append("input")
      .attr("id", "encodesex")
      .attr("type", "radio")
      .attr("name", "encode")
      .attr("value", "Sex")
      .attr("checked", "checked")
      .text("Sex");
    encode.append("span").text("Sex ");
    encode.append("input")
      .attr("id", "encodemedal")
      .attr("type", "radio")
      .attr("name", "encode")
      .attr("value", "Medal")
      .text("Medal");
    encode.append("span").text("Medal");
    d3.select("#encodesex").on("change", function(){
      if (this.checked) {
        d3.selectAll(".videocircle").attr("fill", function(d){
          return c2(d.Sex);
        });
        d3.select(".liandci").selectAll(".li").attr("stroke", function(d){
          return c2(d.Sex);
        });
      }
    });
    d3.select("#encodemedal").on("change", function(){
      if (this.checked) {
        d3.selectAll(".videocircle").attr("fill", function(d){
          return c3(d.Medal);
        });
        d3.select(".liandci").selectAll(".li").attr("stroke", function(d){
          return c3(d.Medal);
        });
      }
    });

    //////////////////////////////////// the sort function /////////////////////////////////////
    d3.select("#vcontrol").append("svg").attr("id", "sortfunc")
      .append("rect")
      .attr("x", "2px")
      .attr("y", "70px")
      .attr("stroke", "black")
      .attr("stroke-width","2px")
      .attr("width", "130px")
      .attr("height", "20px")
      .attr("fill", "white")
      .attr("rx", "2px")
      .attr("ry", "2px")
      .on("click", function(){
        if (notSort) {
          sortPoints();
          notSort = false;
        } else {
          unsortPoints();
          notSort = true;
        } 
      });
var medallengend =["Gold","Silver","Bronze","NA"];
    d3.select("#sortfunc").selectAll(".circlemedal").data(medallengend).enter()
    .append("circle")
    .attr("cx","55px")
    .attr("cy",function(d,i){
      return i*15+10+"px"
    })
    .attr("r","5px")
    .attr("fill",function(d){
      return c3(d) 
    });
    d3.select("#sortfunc").selectAll(".textmedal").data(medallengend).enter()
    .append("text")
    .attr("x","65px")
    .attr("y",function(d,i){
      return i*15+14+"px"
    })  
    .attr("font-size","8px") 
    .text(function(d){
      return d
    });
      var sexlengend=["F","M"]
    d3.select("#sortfunc").selectAll(".circlesex").data(sexlengend).enter()
       .append("circle")
       .attr("cx","8px")
       .attr("cy",function(d,i){
        return i*20+10+"px"
       })
       .attr("r","5px")
       .attr("fill",function(d){
        return c2(d)
       });
    d3.select("#sortfunc").selectAll(".textsex").data(sexlengend).enter()
       .append("text")
       .attr("x","20px")
       .attr("y",function(d,i){
        return i*20+13+"px"
       
       })
       .attr("fill","black")
        .attr("font-size","8px")
       .text(function(d){
        return d
       })

       ;


    d3.select("#sortfunc")
      .append("text")
      .attr("id", "sorttext")
      .attr("x", "66px")
      .attr("y", "85px")
      .style("fill", "black")
      .style("font-size", "13px")
      .style("text-anchor", "middle")
      .style("font-weight", "bold")
      .text("Sort by careertime")
      .on("click", function(){
        if (notSort) {
          sortPoints();
          notSort = false;
        } else {
          unsortPoints();
          notSort = true;
        }       
      }); 
  };


};

function isLastyear(arr, obj){   
  var b = false;

  if (arr[arr.length-1] == obj) {
      b = true;
    }
  return b;
}
function dotheupdate(year) {
  //d3.selectAll(".y" + year).transition("showcircle").duration(1000).style("opacity", 1);
  
  d3.selectAll(".li").each(function(d){
    if (isinArray(d.years, year)) {
        d3.select(this).transition("showline").duration(1000).attr("x2", function(d){ return vxScale(year); });
        if (isLastyear(d.years, year)) {
          d3.select(this).transition("hideline").delay(1000).duration(1000).style("opacity", 0);
        }
    };
  });
  d3.select("#timeline")
    .transition("showtime1").duration(1000).ease(d3.easeLinear).attr("x1", function(d){ return vxScale(year); });
  d3.select("#timeline")
    .transition("showtime2").duration(1000).ease(d3.easeLinear).attr("x2", function(d){ return vxScale(year); });
}

function sortPoints() {
  d3.select(".liandci").selectAll(".li")
    .sort(function(a,b) {
      var alen = (a.years[(a.years.length-1)] - a.years[0]);
      var blen = (b.years[(b.years.length-1)] - b.years[0]);
      return d3.ascending(alen, blen);
    })
    .attr("newindex", function(d, i){
      return i;
    })
    .transition("movey1").duration(500)
    .attr("y1", function(d, i) {
      return vyScale(i);
    });
  d3.select(".liandci").selectAll(".li")
    .transition("movey2").duration(500)
    .attr("y2", function(d, i) {
      return vyScale(i);
    });
  d3.selectAll(".videocircle")
    .transition("movecircle").duration(500)
    .attr("cy", function(d) {
      //console.log("#videoli-"+d.ID);
      var newy = d3.select("#videoli-"+d.ID).attr("newindex");
      //var newy = "10px";
      return vyScale(newy);
    });
  d3.select("#sorttext").text("Unsort");
}
function unsortPoints() {
  d3.select(".liandci").selectAll(".li")
    .transition("movey1").duration(500)
    .attr("y1", function(d) {
      return vyScale(d.newid);
    })
  d3.select(".liandci").selectAll(".li")
    .transition("movey2").duration(500)
    .attr("y2", function(d, i) {
      return vyScale(d.newid);
    });
  d3.select(".liandci").selectAll(".videocircle")
    .transition("movecircle").duration(500)
    .attr("cy", function(d) {
      var newy = d3.select("#videoli-"+d.ID).attr("newid");
      return vyScale(newy);
    });
  d3.select("#sorttext").text("Sort by careertime");
}

function hlInPara1(d) {
  //console.log("I try to highlight!");
  if(d.Sex=="M"){
    d3.select(".foreground_").selectAll("path").attr("opacity",0.01);
    console.log(".ath-" + d.ID)
    d3.select(".foreground_").selectAll(".ath-" + d.ID)
    .attr("stroke", "lightgreen")
    .attr("stroke-width","3px")
    .attr("opacity",1)
    .attr("display","null");

  }else{
     d3.select(".foreground").selectAll("path").attr("opacity",0.01);
      d3.select(".foreground").selectAll(".ath-" + d.ID)
    .attr("stroke", "lightgreen")
    .attr("stroke-width","3px")
    .attr("opacity",1)
    .attr("display","null");
  }
}
function hlInPara2(d) {
  if(d.Sex=="M"){
    d3.select(".foreground_").selectAll("path").attr("opacity",0.01);
    d3.select(".foreground_").selectAll(".ath-" + d.ID)
    .attr("stroke", "lightgreen")
    .attr("stroke-width","3px")
    .attr("opacity",1)
    .attr("display","null");

  }else{
     d3.select(".foreground").selectAll("path").attr("opacity",0.01);
      d3.select(".foreground").selectAll(".ath-" + d.ID)
    .attr("stroke", "lightgreen")
    .attr("stroke-width","3px")
    .attr("opacity",1)
    .attr("display","null");
  }
}

function showDetail1(d) {
  var xPosition = d3.event.pageX + 10 + 'px';
  var yPosition = d3.event.pageY - 10 + 'px'; 
  d3.select("#videotooltip")
    .style("left", function(){
      if ((d3.event.pageX + 150)>1260) {
        return d3.event.pageX - 180 + 'px';
      } else {
        return xPosition;
      }
    })
    .style("top", yPosition)
    .classed("hidden", false)
    .select("p")
    .text("Athlete: " + d.Name);
}
function showDetail2(d) {
  var xPosition = d3.event.pageX + 10 + 'px';
  var yPosition = d3.event.pageY - 10 + 'px'; 
  d3.select("#videotooltip")
    .style("left", function(){
      if ((d3.event.pageX + 150)>1260) {
        return d3.event.pageX - 180 + 'px';
      } else {
        return xPosition;
      }
    })
    .style("top", yPosition)
    .classed("hidden", false)
    .select("p")
    .text("Athlete: " + d.Name);
  d3.select("#videotooltip").append("p").attr("id", "p2").text("Years of entry: " + d.years);
}
d3.select("body").append("div")
  .attr("id", "videotooltip")
  .attr("class", "hidden")
  .append("p");

function cancelhl(){
    d3.select("#videotooltip").classed("hidden", true);
    d3.select(".foreground").selectAll("path").attr("stroke", function(p){
      if (p.Medal==0){
        return "yellow";
      }
      else if (p.Medal==1){
        return "red";
      }
      else if (p.Medal==2){
        return "blue"
      }
      else if(p.Medal ==3) {
        return "gray"
      }else{
        return "white" 
      }})
    .attr("stroke-width","1px")
    .attr("opacity",function(p){
      if (p.Medal ==3){
        return 0.1
      }
    });
  d3.select(".foreground_").selectAll("path").attr("stroke", function(p){
      if (p.Medal==0){
        return "yellow";
      }
      else if (p.Medal==1){
        return "red";
      }
      else if (p.Medal==2){
        return "blue"
      }
      else if(p.Medal ==3) {
        return "gray"
      }else{
        return "white" 
      }})
     .attr("stroke-width","1px")
    .attr("opacity",function(p){
      if (p.Medal ==3){
        return 0.1
      }
  });
}

// drawCareer("USA", "");
