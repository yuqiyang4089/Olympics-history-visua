function isinArray(arr, obj){   
  var b = false;
  for (var i = 0; i < arr.length; i++) {
    if (arr[i] == obj) {
      b = true;
      break;
    }
  }
  return b;
}

var cspo = "Swimming";
var ccou = "CHN";
function showcountry(d, sport){
	//remove the network and old control box
	// d3.select("#video").remove();
	// d3.select(".parallelchart").remove(); 
	// d3.select(".parallelchart2").remove(); 
	if (sport!="") {
		cspo = sport;
	};

	var newcontrol = d3.select("body").append("div").attr("id", "newcontrol").append("svg");
	newcontrol
		.append("rect")
		.attr("x", "5px")
		.attr("y", "5px")
		.attr("width", "170px")
		.attr("height", "18px")
		.attr("fill", "white")
		.attr("stroke", "black")
		.attr("stroke-width", "1.5px")
		.on("click", function(){
			d3.select("#video").remove();
	      	d3.select("#parallelchart").remove();
	      	d3.select("#newcontrol").remove();
	      	d3.select("#vcontrol").remove();
	      	d3.select("#network").attr("width", "88%").attr("height", "100%");
			d3.select("#control").style("display", "inline");
		});
	newcontrol
		.append("text")
		.text("Back to Network")
		.attr("x", "90px")
		.attr("y", "20px")
		.style("font-weight", "bold")
		.style("text-anchor", "middle")
		.on("click", function(){
			d3.select("#video").remove();
	      	d3.select("#parallelchart").remove();
	      	d3.select("#newcontrol").remove();
	      	d3.select("#vcontrol").remove();
	      	d3.select("#network").attr("width", "88%").attr("height", "100%");
			d3.select("#control").style("display", "inline");
		});
	newcontrol
		.append("text")
		.text("Current country: ")
		.attr("x", "5px")
		.attr("y", "40px")
		.style("font-weight", "bold");
	newcontrol
		.append("text")
		.text(d.id)
		.attr("x", "5px")
		.attr("y", "55px");
	newcontrol
		.append("text")
		.text("Current sport: ")
		.attr("x", "5px")
		.attr("y", "70px")
		.style("font-weight", "bold");
	newcontrol
		.append("text")
		.attr("id", "cspo")
		.text(cspo)
		.attr("x", "5px")
		.attr("y", "85px");
	newcontrol
		.append("text")
		.text("Advantage sports: ")
		.attr("x", "5px")
		.attr("y", "100px")
		.style("font-weight", "bold");
	newcontrol
		.append("text")
		.text("(# of gold medals)")
		.style("font-size", "13px")
		.attr("x", "5px")
		.attr("y", "115px")
		.style("font-weight", "bold");
	var textdata = [];
	var textname = [];
	d3.selectAll("."+d.id).each(function(p){
		if (typeof p.target !== 'undefined') {
			if (isinArray(textname, p.target.id)!=true){
				var temp = [p.target.id, p.value];
				textdata.push(temp);
				textname.push(p.target.id);
			}			
		}
	});
	newcontrol.selectAll(".adsports")
		.data(textdata).enter().append("g")
		.attr("class", "adsports");
	newcontrol.selectAll(".adsports").append("rect")
		.attr("x", "5px")
		.attr("y", function(d,i){
			return i*15+117+"px";
		})
		.attr("width", "170px")
		.attr("height", "13px")
		.attr("stroke", "black")
		.attr("stroke-width", "1px")
		.attr("rx", "2px")
		.attr("ry", "2px")
		.attr("fill", "#BDBDBD")
		.on("click", function(p){
			d3.select("#cspo").text(p[0]);
			d3.select("#video").remove();
	      	d3.select("#parallelchart").remove();    	
      		drawCareer(d.id, p[0]);
      		drawParallelchart(p[0], d.id);
		})
		.on("mouseover", function(){
			d3.select(this).attr("fill", "#AAAAAA");
		})
		.on("mouseout", function(){
			d3.select(this).attr("fill", "#BDBDBD");
		});
	newcontrol.selectAll(".adsports").append("rect")
		.attr("x", "145px")
		.attr("y", function(d,i){
			return i*15+118+"px";
		})
		.attr("width", "22px")
		.attr("height", "11px")
		.attr("stroke", "black")
		.attr("stroke-width", "1px")
		.attr("rx", "2px")
		.attr("ry", "2px")
		.attr("fill", "#BDBDBD")
		.on("click", function(p){
			searchinWiki(p[0]);
		})
		.on("mouseover", function(){
			d3.select(this).attr("fill", "#AAAAAA");
		})
		.on("mouseout", function(){
			d3.select(this).attr("fill", "#BDBDBD");
		});
	newcontrol.selectAll(".adsports").append("text")
		.attr("x", "145px")
		.attr("y", function(d,i){
			return i*15+128+"px";
		})
		.text("wiki")
		.style("font-size", "10px")
		.style("font-weight", "bold")
		.on("click", function(p){
			searchinWiki(p[0]);
		});
	newcontrol.selectAll(".adsports").append("text")
		.text(function(d){
			return d[0]+"("+d[1]+")";
		})
		.style("font-size", "13px")
		.attr("x", "10px")
		.attr("y", function(d,i){
			return i*15+128+"px";
		})
		.on("click", function(p){
			d3.select("#cspo").text(p[0]);
			d3.select("#video").remove();
	      	d3.select("#parallelchart").remove();     	
      		drawCareer(d.id, p[0]);
      		drawParallelchart(p[0], d.id);
		});
}

function showsport(country, d){
	//remove the network and old control box
	// d3.select("#video").remove();
	// d3.select(".parallelchart").remove(); 
	// d3.select(".parallelchart2").remove(); 
	if (country!="") {
		ccou = country;
	};

	var newcontrol = d3.select("body").append("div").attr("id", "newcontrol").append("svg");
	newcontrol
		.append("rect")
		.attr("x", "5px")
		.attr("y", "5px")
		.attr("width", "170px")
		.attr("height", "18px")
		.attr("fill", "white")
		.attr("stroke", "black")
		.attr("stroke-width", "1.5px")
		.on("click", function(){
			d3.select("#video").remove();
	      	d3.select("#parallelchart").remove();
	      	d3.select("#newcontrol").remove();
	      	d3.select("#vcontrol").remove();
	      	d3.select("#network").attr("width", "88%").attr("height", "100%");
			d3.select("#control").style("display", "inline");
		});
	newcontrol
		.append("text")
		.text("Back to Network")
		.attr("x", "90px")
		.attr("y", "20px")
		.style("font-weight", "bold")
		.style("text-anchor", "middle")
		.on("click", function(){
			d3.select("#video").remove();
	      	d3.select("#parallelchart").remove();
	      	d3.select("#newcontrol").remove();
	      	d3.select("#vcontrol").remove();
	      	d3.select("#network").attr("width", "88%").attr("height", "100%");
			d3.select("#control").style("display", "inline");
		});
	newcontrol
		.append("text")
		.text("Current country: ")
		.attr("x", "5px")
		.attr("y", "40px")
		.style("font-weight", "bold");
	newcontrol
		.append("text")
		.attr("id", "ccou")
		.text(ccou)
		.attr("x", "5px")
		.attr("y", "55px");
	newcontrol
		.append("text")
		.text("Current sport: ")
		.attr("x", "5px")
		.attr("y", "70px")
		.style("font-weight", "bold");
	newcontrol
		.append("text")
		.text(d.id)
		.attr("x", "5px")
		.attr("y", "85px");
	newcontrol
		.append("text")
		.text("Monopolized countries: ")
		.attr("x", "5px")
		.attr("y", "100px")
		.style("font-weight", "bold");
	newcontrol
		.append("text")
		.text("(# of gold medals)")
		.style("font-size", "13px")
		.attr("x", "5px")
		.attr("y", "115px")
		.style("font-weight", "bold");
	var textdata = [];
	var textname = [];
	d3.selectAll("."+d.id).each(function(p){
		if (typeof p.source !== 'undefined') {
			if (isinArray(textname, p.source.id)!=true){
				var temp = [p.source.id, p.value];
				textdata.push(temp);
				textname.push(p.source.id);
			}			
		}
	});
	newcontrol.selectAll(".monocs")
		.data(textdata).enter().append("g")
		.attr("class", "monocs");
	newcontrol.selectAll(".monocs").append("rect")
		.attr("x", "5px")
		.attr("y", function(d,i){
			return i*15+117+"px";
		})
		.attr("width", "170px")
		.attr("height", "13px")
		.attr("stroke", "black")
		.attr("stroke-width", "1px")
		.attr("rx", "2px")
		.attr("ry", "2px")
		.attr("fill", "#BDBDBD")
		.on("click", function(p){
			d3.select("#ccou").text(p[0]);
			d3.select("#video").remove();
	      	d3.select("#parallelchart").remove();    	
      		drawCareer(p[0], d.id);
      		drawParallelchart(d.id, p[0]);
		})
		.on("mouseover", function(){
			d3.select(this).attr("fill", "#AAAAAA");
		})
		.on("mouseout", function(){
			d3.select(this).attr("fill", "#BDBDBD");
		});
	newcontrol.selectAll(".monocs").append("rect")
		.attr("x", "145px")
		.attr("y", function(d,i){
			return i*15+118+"px";
		})
		.attr("width", "22px")
		.attr("height", "11px")
		.attr("stroke", "black")
		.attr("stroke-width", "1px")
		.attr("rx", "2px")
		.attr("ry", "2px")
		.attr("fill", "#BDBDBD")
		.on("click", function(p){
			searchinWiki(p[0]);
		})
		.on("mouseover", function(){
			d3.select(this).attr("fill", "#AAAAAA");
		})
		.on("mouseout", function(){
			d3.select(this).attr("fill", "#BDBDBD");
		});
	newcontrol.selectAll(".monocs").append("text")
		.attr("x", "145px")
		.attr("y", function(d,i){
			return i*15+128+"px";
		})
		.text("wiki")
		.style("font-size", "10px")
		.style("font-weight", "bold")
		.on("click", function(p){
			searchinWiki(p[0]);
		});
	newcontrol.selectAll(".monocs").append("text")
		.text(function(d){
			return d[0]+"("+d[1]+")";
		})
		.style("font-size", "13px")
		.attr("x", "10px")
		.attr("y", function(d,i){
			return i*15+128+"px";
		})
		.on("click", function(p){
			d3.select("#ccou").text(p[0]);
			d3.select("#video").remove();
	      	d3.select("#parallelchart").remove();     	
      		drawCareer(p[0], d.id);
      		drawParallelchart(d.id, p[0]);
		});
}

function searchinWiki(name){
	var url = "https://en.wikipedia.org/wiki/"+name;
	window.open(url);
}