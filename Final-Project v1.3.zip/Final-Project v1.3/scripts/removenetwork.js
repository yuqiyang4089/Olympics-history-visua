function isinArray(arr, obj){   
  var b = false;
  for (var i = 0; i < arr.length; i++) {
    if (arr[i] == obj) {
      b = true;
      break;
    }
  }
  return b;
}

var cspo = "Swimming";
var ccou = "CHN";
function showcountry(d, sport){
	//remove the network and old control box
	// d3.select("#video").remove();
	// d3.select(".parallelchart").remove(); 
	// d3.select(".parallelchart2").remove(); 
	if (sport!="") {
		cspo = sport;
	};

	var newcontrol = d3.select("body").append("div").attr("id", "newcontrol").append("svg");
	newcontrol
		.append("rect")
		.attr("x", "5px")
		.attr("y", "5px")
		.attr("width", "170px")
		.attr("height", "18px")
		.attr("fill", "white")
		.attr("stroke", "black")
		.attr("stroke-width", "1.5px")
		.on("click", function(){
			d3.select("#video").remove();
	      	d3.select(".parallelchart").remove();     	
	      	d3.select(".parallelchart2").remove();
	      	d3.select("#newcontrol").remove();
	      	d3.select("#vcontrol").remove();
	      	d3.select("#network").attr("width", "88%").attr("height", "100%");
			d3.select("#control").style("display", "inline");
		});
	newcontrol
		.append("text")
		.text("Back to Network")
		.attr("x", "90px")
		.attr("y", "20px")
		.style("font-weight", "bold")
		.style("text-anchor", "middle")
		.on("click", function(){
			d3.select("#video").remove();
	      	d3.select(".parallelchart").remove();     	
	      	d3.select(".parallelchart2").remove();
	      	d3.select("#newcontrol").remove();
	      	d3.select("#vcontrol").remove();
	      	d3.select("#network").attr("width", "88%").attr("height", "100%");
			d3.select("#control").style("display", "inline");
		});
	newcontrol
		.append("text")
		.text("Current country: ")
		.attr("x", "5px")
		.attr("y", "40px")
		.style("font-weight", "bold");
	newcontrol
		.append("text")
		.text(d.id)
		.attr("x", "5px")
		.attr("y", "55px");
	newcontrol
		.append("text")
		.text("Current sport: ")
		.attr("x", "5px")
		.attr("y", "70px")
		.style("font-weight", "bold");
	newcontrol
		.append("text")
		.attr("id", "cspo")
		.text(cspo)
		.attr("x", "5px")
		.attr("y", "85px");
	newcontrol
		.append("text")
		.text("Advantage sports: ")
		.attr("x", "5px")
		.attr("y", "100px")
		.style("font-weight", "bold");
	var textdata = [];
	d3.selectAll("."+d.id).each(function(p){
		if (typeof p.target !== 'undefined') {
			if (isinArray(textdata, p.target.id)!=true){
				textdata.push(p.target.id);
			}			
		}
	});
	newcontrol.selectAll(".adsports")
		.data(textdata).enter().append("text")
		.attr("class", "adsports")
		.text(function(d){
			return d;
		})
		.style("font-size", "13px")
		.attr("x", "10px")
		.attr("y", function(d,i){
			return i*15+113+"px";
		})
		.on("click", function(p){
			d3.select("#cspo").text(p);
			d3.select("#video").remove();
	      	d3.select(".parallelchart").remove();  
	      	d3.select(".parallelchart2").remove();     	
      		drawCareer(d.id, p);
      		drawParallelchart(p, d.id);
		});
}

function showsport(country, d){
	//remove the network and old control box
	// d3.select("#video").remove();
	// d3.select(".parallelchart").remove(); 
	// d3.select(".parallelchart2").remove(); 
	if (country!="") {
		ccou = country;
	};

	var newcontrol = d3.select("body").append("div").attr("id", "newcontrol").append("svg");
	newcontrol
		.append("rect")
		.attr("x", "5px")
		.attr("y", "5px")
		.attr("width", "170px")
		.attr("height", "18px")
		.attr("fill", "white")
		.attr("stroke", "black")
		.attr("stroke-width", "1.5px")
		.on("click", function(){
			d3.select("#video").remove();
	      	d3.select(".parallelchart").remove();     	
	      	d3.select(".parallelchart2").remove();
	      	d3.select("#newcontrol").remove();
	      	d3.select("#vcontrol").remove();
	      	d3.select("#network").attr("width", "88%").attr("height", "100%");
			d3.select("#control").style("display", "inline");
		});
	newcontrol
		.append("text")
		.text("Back to Network")
		.attr("x", "90px")
		.attr("y", "20px")
		.style("font-weight", "bold")
		.style("text-anchor", "middle")
		.on("click", function(){
			d3.select("#video").remove();
	      	d3.select(".parallelchart").remove();     	
	      	d3.select(".parallelchart2").remove();
	      	d3.select("#newcontrol").remove();
	      	d3.select("#vcontrol").remove();
	      	d3.select("#network").attr("width", "88%").attr("height", "100%");
			d3.select("#control").style("display", "inline");
		});
	newcontrol
		.append("text")
		.text("Current country: ")
		.attr("x", "5px")
		.attr("y", "40px")
		.style("font-weight", "bold");
	newcontrol
		.append("text")
		.attr("id", "ccou")
		.text(ccou)
		.attr("x", "5px")
		.attr("y", "55px");
	newcontrol
		.append("text")
		.text("Current sport: ")
		.attr("x", "5px")
		.attr("y", "70px")
		.style("font-weight", "bold");
	newcontrol
		.append("text")
		.text(d.id)
		.attr("x", "5px")
		.attr("y", "85px");
	newcontrol
		.append("text")
		.text("Monopolized countries: ")
		.attr("x", "5px")
		.attr("y", "100px")
		.style("font-weight", "bold");
	var textdata = [];
	d3.selectAll("."+d.id).each(function(p){
		if (typeof p.source !== 'undefined') {
			if (isinArray(textdata, p.source.id)!=true){
				textdata.push(p.source.id);
			}			
		}
	});
	newcontrol.selectAll(".monocs")
		.data(textdata).enter().append("text")
		.attr("class", "monocs")
		.text(function(d){
			return d;
		})
		.style("font-size", "13px")
		.attr("x", "10px")
		.attr("y", function(d,i){
			return i*15+113+"px";
		})
		.on("click", function(p){
			d3.select("#ccou").text(p);
			d3.select("#video").remove();
	      	d3.select(".parallelchart").remove();  
	      	d3.select(".parallelchart2").remove();     	
      		drawCareer(p, d.id);
      		drawParallelchart(d.id, p);
      		console.log(p);
      		console.log(d.id);
		});
}